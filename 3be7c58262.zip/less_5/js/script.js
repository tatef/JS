let menu = document.querySelector('.menu'),
menuItem = document.getElementsByClassName('menu-item'),
title = document.querySelector('#title'),
column = document.querySelectorAll('.column'),
adv = document.querySelector('.adv'),
ul = document.createElement('ul');
//a = prompt("Ваше отношение к технике Apple", ''),
//p = document.querySelector('#prompt');
menu.replaceChild(menuItem[2], menuItem[1]);
//menu.replaceChild(menuItem[2], menuItem[2]);
ul.classList.add('menu-item');
menu.appendChild(ul);
ul.innerHTML = 'Пятый пункт';
title.innerHTML = 'Мы продаем только подлинную технику Apple';
column[1].removeChild(adv);
//document.body.style.backgroundImage = 'url(..\img\apple_true.jpg)';